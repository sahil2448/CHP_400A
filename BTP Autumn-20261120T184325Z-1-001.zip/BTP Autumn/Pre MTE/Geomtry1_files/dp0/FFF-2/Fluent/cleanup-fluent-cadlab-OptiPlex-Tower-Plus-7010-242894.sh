/ansys_inc/v241/fluent/bin/fluent-cleanup.pl cadlab-OptiPlex-Tower-Plus-7010 42971 CLEANUP_EXITING

LOCALHOST=`hostname -s`
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 243137; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 243137; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 242894; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 242894; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 242680; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 242680; fi

rm -f /home/students/BTP_WORK_Sahil_Yuvraj_Kamble/Geomtry1_files/dp0/FFF-2/Fluent/cleanup-fluent-cadlab-OptiPlex-Tower-Plus-7010-242894.sh
