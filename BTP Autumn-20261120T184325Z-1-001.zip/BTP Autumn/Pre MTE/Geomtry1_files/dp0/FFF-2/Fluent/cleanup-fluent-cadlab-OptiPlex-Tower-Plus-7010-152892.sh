/ansys_inc/v241/fluent/bin/fluent-cleanup.pl cadlab-OptiPlex-Tower-Plus-7010 38007 CLEANUP_EXITING

LOCALHOST=`hostname -s`
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 153134; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 153134; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 152892; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 152892; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 152676; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 152676; fi

rm -f /home/students/BTP_WORK_Sahil_Yuvraj_Kamble/Geomtry1_files/dp0/FFF-2/Fluent/cleanup-fluent-cadlab-OptiPlex-Tower-Plus-7010-152892.sh
