#include "udf.h"

   DEFINE_PROFILE(inlet_velocity, thread, position)
   {
       real x[ND_ND];   /* will hold the (x,y) coordinates of each face */
       real y;
       face_t f;
       real H = 4.0;    /* channel height in meters — matches your geometry */

       begin_f_loop(f, thread)
       {
           F_CENTROID(x, f, thread);
           y = x[1];    /* the y-coordinate is the 2nd entry of the array */
           F_PROFILE(f, thread, position) = 1.5 * (1.0 - pow(1.0 - 2.0*y/H, 2.0));
       }
       end_f_loop(f, thread)
   }
