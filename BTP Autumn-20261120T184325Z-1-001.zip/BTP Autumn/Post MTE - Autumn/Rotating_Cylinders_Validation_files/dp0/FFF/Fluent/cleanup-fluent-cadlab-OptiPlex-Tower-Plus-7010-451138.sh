/ansys_inc/v241/fluent/bin/fluent-cleanup.pl cadlab-OptiPlex-Tower-Plus-7010 38185 CLEANUP_EXITING

LOCALHOST=`hostname -s`
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 451381; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 451381; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 451138; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 451138; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 450923; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 450923; fi

rm -f /home/students/BTP_WORK_Sahil_Yuvraj_Kamble/Post MTE - Autumn/Rotating_Cylinders_Validation_files/dp0/FFF/Fluent/cleanup-fluent-cadlab-OptiPlex-Tower-Plus-7010-451138.sh
