/ansys_inc/v241/fluent/bin/fluent-cleanup.pl cadlab-OptiPlex-Tower-Plus-7010 43369 CLEANUP_EXITING

LOCALHOST=`hostname -s`
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 22814; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 22814; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 22572; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 22572; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 22355; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 22355; fi

rm -f /home/students/BTP_WORK_Sahil_Yuvraj_Kamble/Post MTE - Autumn/Rotating_Cylinders_Validation_files/dp0/FFF/Fluent/cleanup-fluent-cadlab-OptiPlex-Tower-Plus-7010-22572.sh
