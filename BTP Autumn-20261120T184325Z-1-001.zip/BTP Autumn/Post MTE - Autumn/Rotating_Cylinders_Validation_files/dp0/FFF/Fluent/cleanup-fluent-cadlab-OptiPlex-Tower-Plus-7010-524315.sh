/ansys_inc/v241/fluent/bin/fluent-cleanup.pl cadlab-OptiPlex-Tower-Plus-7010 45291 CLEANUP_EXITING

LOCALHOST=`hostname -s`
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 524559; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 524559; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 524315; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 524315; fi
if [[ cadlab-OptiPlex-Tower-Plus-7010 == "$LOCALHOST"* ]]; then kill -9 524101; else ssh cadlab-OptiPlex-Tower-Plus-7010 kill -9 524101; fi

rm -f /home/students/BTP_WORK_Sahil_Yuvraj_Kamble/Post MTE - Autumn/Rotating_Cylinders_Validation_files/dp0/FFF/Fluent/cleanup-fluent-cadlab-OptiPlex-Tower-Plus-7010-524315.sh
