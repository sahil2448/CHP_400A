#include "udf.h"

#define UM    0.011044902
#define D_CH  0.1
#define Y_BOTTOM 0.0

DEFINE_PROFILE(inlet_x_velocity, thread, position)
{
    face_t f;
    real xyz[ND_ND];
    real eta;

    begin_f_loop(f, thread)
    {
        F_CENTROID(xyz, f, thread);

        eta = 2.0 * (xyz[1] - (Y_BOTTOM + 0.5 * D_CH)) / D_CH;

        F_PROFILE(f, thread, position) =
            2.0 * UM * (1.0 - eta * eta);
    }
    end_f_loop(f, thread)
}
